<?php 	
	$siteTitle = "Kirby's Costumes";
	$pageTitle = "Guestbook";

	$file = file_get_contents('data/guestbook.json');
	$messages = json_decode($file, JSON_PRETTY_PRINT);
	
	if (isset($_POST['message'])) {
		$messages[] = $_POST['message'];
		$json = json_encode($messages);
		file_put_contents('data/guestbook.json', $json);
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Costume</title>
	<link rel="stylesheet" href="assets/style.css">
</head>
<body>

	<!-- Header -->
	<header class="header">
		<h1>
			<a href="index.php"><?= $siteTitle ?></a>
		</h1>
		<h2>
			<?= $pageTitle ?>
		</h2>
	</header>

	<main class="guestbook">

		<!-- <?php var_dump($messages); ?> -->

		<?php foreach ($messages as $message): ?>
			<div class="message">
				<?= $message ?>
			</div>
		<?php endforeach; ?>

		<form class="form" method="POST">
			<textarea name="message" rows="3" required></textarea>
			<input type="submit" value="Submit">
		</form>
	</main>
</body>
</html>