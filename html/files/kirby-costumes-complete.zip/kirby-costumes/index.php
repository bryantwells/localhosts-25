<?php 
	$siteTitle = "Kirby's Costumes";
	$pageTitle = "Home";
	$costumes = json_decode(file_get_contents('./data/kirby.json'));
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="assets/style.css">
</head>
<body>

	<!-- Header -->
	<header class="header">
		<h1>
			<?= $siteTitle ?>
		</h1>
		<h2>
			<?= $pageTitle ?>
		</h2>
	</header>

	<!-- Main -->
	<main class="costumes">

		<!-- <pre><?= var_dump($costumes) ?></pre> -->

		<?php foreach ($costumes as $id => $costume): ?>

			<!-- <pre><?= var_dump($costume) ?></pre> -->

			<a href="costume.php?id=<?= $id ?>">
				<figure class="thumbnail">
					<img src="media/<?= $costume->image ?>">
					<figcaption>
						<?= $costume->title ?>
					</figcaption>
				</figure>
			</a>

		<?php endforeach; ?>
	</main>

	<footer class="footer">
		<a href="guestbook.php">Sign the guestbook!</a>
	</footer>

</body>
</html>