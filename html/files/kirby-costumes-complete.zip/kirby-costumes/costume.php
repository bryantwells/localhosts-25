<?php 
	$costumes = json_decode(file_get_contents('./data/kirby.json'));
	$id = $_GET['id'];
	$costume = $costumes->$id;
	
	$siteTitle = "Kirby's Costumes";
	$pageTitle = $costume->title;
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Costume</title>
	<link rel="stylesheet" href="assets/style.css">
</head>
<body>

	<!-- Header -->
	<header class="header">
		<h1>
			<a href="index.php"><?= $siteTitle ?></a>
		</h1>
		<h2>
			<?= $pageTitle ?>
		</h2>
	</header>

	<main class="costume">
		<header class="costume-header">
			<img src="media/<?= $costume->image ?>" alt="" srcset="">
		</header>
		<p class="costume-description">
			<?= $costume->description ?>
		</p>
		<footer class="costume-footer">
			<?php foreach ($costume->colors as $color): ?>
				<div class="swatch" style="background-color: <?= $color ?>"></div>
			<?php endforeach; ?>
		</footer>
	</main>
</body>
</html>