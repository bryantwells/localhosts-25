<?php 	

	// get the current URL
	$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

	// get the number at the end of the URL
	$i = basename($path);

	// get the data from the json file 
	$data = file_get_contents('data/frames.json');

	// turn it into a list
	$frames = json_decode($data, JSON_PRETTY_PRINT);

	// get the current frame
	$frame = $frames[$i];
	
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="/assets/style.css">
</head>
<body>
	<div class="frame-display">
		<img src="../media/<?= $frame ?>" />
	</div>
</body>
</html>