<?php 	

	// define a new variable
	$pageTitle = "Frames";

	// get the data from the json file 
	$data = file_get_contents('data/frames.json');

	// turn it into a list
	$frames = json_decode($data, JSON_PRETTY_PRINT);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?= $pageTitle ?></title>
	<link rel="stylesheet" href="assets/style.css">
</head>
<body>

	<div class="frame-list">

		<!-- <?php var_dump($frames); ?> -->

		<?php foreach ($frames as $i=>$frame): ?>
			<div class="frame-thumbnail">
				<a href="entry/<?= $i ?>">
					<img src="media/<?= $frame ?>" alt="" srcset="">
				</a>
			</div>
		<?php endforeach; ?>

	</div>

</body>
</html>