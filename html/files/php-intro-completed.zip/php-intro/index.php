<?php

	// define routes as URL prefix and file
	$routes = [
		'/entry' => 'entry.php',
		'/' => 'home.php',
	];

	// check the URL to see if it matches any routes
	$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
	
	//  go through each route..
	foreach ($routes as $prefix => $file) {

		// if the current url starts with a matching route...
		if (str_starts_with($uri, $prefix)) {

			// 'require' the matching file
			require $file;
			break;
		}
	}

?>