// STRINGS
// ------------------------------------------------

console.log('\n\nSTRINGS\n\n\n'); // header

console.log('A string with single quotes.'); // single quote
console.log("A string with 'double quotes'."); // double quotes
console.log(`A string with back ticks.`); // back ticks
console.log('A ' + 'string ' + 'in ' + 'pieces.'); // concatenate


// NUMBERS
// ------------------------------------------------

console.log('\n\nNUMBERS\n\n\n'); // header

console.log(100); // number
console.log(100 + 100); // add
console.log(100 - 100); // subtract
console.log(100 * 100); // multiply
console.log(100 / 100); // divide
console.log(100 % 30); // modulo


// STRINGS & NUMBERS
// ------------------------------------------------

console.log('\n\nSTRINGS & NUMBERS\n\n\n'); // header

console.log('100 * 50'); // numbers in a string
console.log('100 * 50 equals ' + 100 * 50); // adding number to a string
console.log(100 * 50 + '25'); // adding string to a number
console.log(`The year was ${ 2024 - 333 } 333 years ago.`); // putting a number in a string


// BOOLEANS
// ------------------------------------------------

console.log('\n\nBOOLEANS\n\n\n'); // header

console.log(true, false); // true, false
console.log('3 < 4 :', 3 < 4); // less than 
console.log('5 > 10 :', 5 > 10); // more than 
console.log('2 <= 2 :', 2 <= 2); // less than or equal to
console.log('6 >= 3 :', 6 >= 3); // less than or equal to
console.log("8 + 2 == 5 + 5 : ", 8 + 2 == 5 + 5); // equal to
console.log("'tomato' != 'vegetable' : ", 'tomato' != 'vegetable'); // unequal to
console.log('2 > 1 && 2 < 12 :', 2 > 1 && 2 < 12); // 'AND' operator
console.log('5 > 12 || 6 <= 18 :', 5 > 12 || 6 <= 18); // 'OR' operator


// STORING VARIABLES
// ------------------------------------------------

console.log('\n\nSTORING VARIABLES\n\n\n'); // header

var myStreetNumber = 2;
var neighborStreetNumber = myStreetNumber + 2;
console.log('myStreetNumber :', myStreetNumber);
console.log('neighborStreetNumber :', neighborStreetNumber);


// ALTERING VARIABLES
// ------------------------------------------------

console.log('\n\nALTERING VARIABLES\n\n\n'); // header

var studentLoanDebt = 800;
console.log('studentLoanDebt :', studentLoanDebt);

studentLoanDebt = studentLoanDebt - 100;
console.log('studentLoanDebt :', studentLoanDebt);

studentLoanDebt = studentLoanDebt + 50;
console.log('studentLoanDebt :', studentLoanDebt);

studentLoanDebt++;
console.log('studentLoanDebt :', studentLoanDebt);

studentLoanDebt--;
console.log('studentLoanDebt :', studentLoanDebt);


// ARRAYS
// ------------------------------------------------

console.log('\n\nARRAYS\n\n\n'); // header

var favoriteColors = ['yellowgreen', 'fuchsia', 'gainsboro', 'snow']; // array definition
console.log('favoriteColors :', favoriteColors); 
console.log('favoriteColors.length :', favoriteColors.length); // array method
console.log('favoriteColors[1] :', favoriteColors[1]); // bracket notation

favoriteColors[1] = 'purple'; // alter array
console.log('favoriteColors[1] :', favoriteColors[1]); // bracket notation


// OBJECTS
// ---------------------
console.log('\n\nOBJECTS\n\n\n'); // header

var me = {
    firstName: 'Bryant',
    lastName: 'Wells',
    favoriteColors: favoriteColors,
}
console.log(me);
console.log("me['firstName'] :", me['firstName']);
console.log(me.lastName);
console.log(document);
document.bgColor = favoriteColors[0];


// CONDITIONAL STATEMENTS
// ---------------------
console.log('\n\nCONDITIONAL STATEMENTS\n\n\n'); // header

var dollarsInPocket = 13;
console.log('dollarsInPocket :', dollarsInPocket);

if (dollarsInPocket >= 3) {
    console.log('I can get a coffee :)');
} else {
    console.log("I can have water :')");
}

// LOOPS
// ---------------------
console.log('\n\nLOOPS\n\n\n'); // header

var apples = '🍎 ';

for (var i = 0; i <= 5; i++) {
    console.log(apples);
    apples = apples + '🍎 ';
}


// FUNCTIONS
// ---------------------
console.log('\n\nFUNCTIONS\n\n\n'); // header

function appleTree(size) {
	var apples = '🍎 ';
    for (var i = 0; i <= size; i++) {
		console.log(apples);
		apples = apples + '🍎 ';
	}
}

appleTree(9);