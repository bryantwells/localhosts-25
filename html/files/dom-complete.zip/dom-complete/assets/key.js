// Get DOM Elements
// ---------------------------------------------
var display = document.querySelector('.Display');


// Create Functions
// ---------------------------------------------
function activateDisplay(event) {
	if (event.keyCode == 32) {
		display.classList.add('is-active');
	}
}
function deactivateDisplay(event) {
	if (event.keyCode == 32) {
		display.classList.remove('is-active');
	}
}

// Event Listeners
// ---------------------------------------------
document.addEventListener('keydown', activateDisplay);
document.addEventListener('keyup', deactivateDisplay);