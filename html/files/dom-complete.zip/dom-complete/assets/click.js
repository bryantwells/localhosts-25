
// Define Variable
// ---------------------------------------------
var clickCount = 0;
console.log('clickCount:', clickCount);


// Get DOM Elements
// ---------------------------------------------
var display = document.querySelector('.Display');
console.log('display:', display);


// Manipulate DOM
// ---------------------------------------------
display.innerText = clickCount;
display.style.fontSize = `${ clickCount * 10 + 10 }px`;


// Create Functions
// ---------------------------------------------
function increaseClickCount() {
    clickCount += 1;
    display.innerText = clickCount;
    display.style.fontSize = `${ clickCount * 10 + 10 }px`;
    console.log('clickCount :', clickCount);
}


// Event Listeners
// ---------------------------------------------
document.addEventListener('click', increaseClickCount);