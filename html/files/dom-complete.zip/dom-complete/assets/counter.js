// Define Variable
// ---------------------------------------------
var count = 1;


// Get DOM Elements
// ---------------------------------------------

var display = document.querySelector('.Display');
var addButton = document.querySelector('.Button--add');
var removeButton = document.querySelector('.Button--remove');


// Event Listeners
// ---------------------------------------------

addButton.addEventListener('click', function() {
	display.innerHTML += `<div class="Bead"></div>`;
});

removeButton.addEventListener('click', function() {
	var lastBead = display.lastChild;
    display.removeChild(lastBead);
});