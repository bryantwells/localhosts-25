<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="assets/style.css">
</head>
<body>

	<!-- HEADER -->
	<header class="header">
	</header>

	<!-- MAIN -->
	<main class="costumes">
	</main>

	<!-- FOOTER -->
	<footer class="footer">
		<a href="guestbook.php">Sign the guestbook!</a>
	</footer>

</body>
</html>