<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Costume</title>
	<link rel="stylesheet" href="assets/style.css">
</head>
<body>

	<!-- HEADER -->
	<header class="header">
	</header>

	<!-- MAIN -->
	<main class="guestbook">
	</main>

	<!-- FOOTER -->
	<footer class="footer">
		<a href="index.php">Back Home</a>
	</footer>

</body>
</html>